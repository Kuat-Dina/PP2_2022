from traceback import print_tb
import _1
import _5
import _13

print(_1.ounces_to_grams(456))
_5.print_all_prem("45")
_13.guess_the_game()